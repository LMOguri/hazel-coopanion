import hashlib,json,shutil,urllib.request,argparse
from datetime import datetime
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--web',type=Path,required=True)
args=parser.parse_args()
web=args.web.resolve()
target=web/'pet-app.js'
health=json.load(urllib.request.urlopen('http://127.0.0.1:9881/health',timeout=10))
assert health['ready'], 'Voice service is not ready'
source=target.read_text(encoding='utf-8')
if "from './hazel-tts.js'" in source:
    assert (web/'hazel-tts.js').read_bytes()==(root/'hazel-tts.js').read_bytes(), 'Different adapter installed; review before replacing'
    print('Already installed; no overwrite')
    raise SystemExit(0)
changes=[
 ("import { createSpeech, textSteps } from './speech.js';", "import { createSpeech, textSteps } from './hazel-tts.js';"),
 ("const speech = createSpeech(sfx, { onUnit: () => body?.talk() });", "const speech = createSpeech(sfx, { onUnit: () => body?.talk(), isHazel: () => shownPack?.id === 'hazel' });"),
 ("if (it.beatDone && (T < it.holdUntil ||", "if (it.beatDone && (speech.busy || T < it.holdUntil ||"),
]
for old,new in changes:
    assert source.count(old)==1, 'Unexpected app version; refusing patch'
    source=source.replace(old,new)
backup=root/'desktop-backups'/datetime.now().strftime('%Y%m%d-%H%M%S')
backup.mkdir(parents=True)
shutil.copy2(target,backup/'pet-app.js')
adapter=web/'hazel-tts.js'
assert not adapter.exists(), 'Unexpected existing adapter; refusing overwrite'
shutil.copy2(root/'hazel-tts.js',adapter)
target.write_text(source,encoding='utf-8')
report=dict(target=str(target),backup=str(backup/'pet-app.js'),adapter=str(adapter),patched_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),adapter_sha256=hashlib.sha256(adapter.read_bytes()).hexdigest())
(root/'desktop-install.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('Installed; reload pet page or restart Coopanion to activate')
