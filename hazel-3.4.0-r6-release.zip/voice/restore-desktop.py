import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'desktop-install.json').read_text())
target=Path(report['target']); adapter=Path(report['adapter'])
assert hashlib.sha256(target.read_bytes()).hexdigest()==report['patched_sha256'], 'App changed after install; restore manually to avoid overwriting updates'
assert hashlib.sha256(adapter.read_bytes()).hexdigest()==report['adapter_sha256'], 'Adapter changed after install'
shutil.copy2(report['backup'],target)
adapter.unlink()
print('Original desktop files restored; restart Coopanion')
