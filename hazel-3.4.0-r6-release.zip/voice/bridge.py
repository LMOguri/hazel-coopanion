"""Local desktop adapter. No credentials, cloud calls, or persistent conversation cache."""
import asyncio, json, re, urllib.request
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request, Response, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
import uvicorn

ROOT=Path(__file__).resolve().parent
PROFILE=json.loads((ROOT/'voice-profile.json').read_text(encoding='utf-8'))
PROFILE['reference_audio']=str((ROOT/PROFILE['reference_audio']).resolve())
app=FastAPI()
app.add_middleware(CORSMiddleware,allow_origins=['http://127.0.0.1:7797','http://localhost:7797','http://127.0.0.1:9881'],allow_methods=['GET','POST'],allow_headers=['Content-Type'])
gate=asyncio.Lock()
class Speak(BaseModel):
    text:str=Field(min_length=1,max_length=600)
def clean(text):
    text=re.sub(r'<[^>]*>|【[^】]*】|\[[^\]]*\]', '',text)
    return re.sub(r'\s+', ' ',text).strip()
def synth(text):
    payload=dict(text=text,text_lang='zh',ref_audio_path=PROFILE['reference_audio'],prompt_text=PROFILE['prompt_text'],prompt_lang='zh',top_k=5,top_p=0.85,temperature=0.8,text_split_method='cut0',batch_size=1,speed_factor=PROFILE.get('speed_factor',1.0),seed=42,media_type='wav',streaming_mode=False,parallel_infer=True)
    req=urllib.request.Request('http://127.0.0.1:9880/tts',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=120) as res:return res.read()
@app.get('/health')
async def health():
    def ping():
        with urllib.request.urlopen('http://127.0.0.1:9880/openapi.json',timeout=3) as r:return r.status==200
    try:ready=await asyncio.to_thread(ping)
    except Exception:ready=False
    return {'ready':ready,'voice':'灰泽满','mode':'reference_conditioned','source_index':PROFILE['source_index']}
@app.get('/')
async def index():return FileResponse(ROOT/'voice-preview.html')
@app.websocket('/speech')
async def desktop_speech(socket:WebSocket):
    if socket.headers.get('origin') not in {'http://127.0.0.1:7797','http://localhost:7797'}:
        await socket.close(code=1008)
        return
    await socket.accept()
    try:
        body=Speak.model_validate(await socket.receive_json())
        text=clean(body.text)
        if not text:
            await socket.close(code=1008)
            return
        async with gate:
            data=await asyncio.to_thread(synth,text)
        await socket.send_bytes(data)
        await socket.close()
    except Exception:
        try:await socket.close(code=1011)
        except Exception:pass
@app.post('/speak')
async def speak(body:Speak,request:Request):
    text=clean(body.text)
    if not text:raise HTTPException(422,'No spoken text')
    async with gate:
        if await request.is_disconnected():return Response(status_code=499)
        try:data=await asyncio.to_thread(synth,text)
        except Exception as exc:raise HTTPException(503,'Local voice synthesis failed; check api-error.log') from exc
    return Response(data,media_type='audio/wav',headers={'Cache-Control':'no-store'})
if __name__=='__main__':uvicorn.run(app,host='127.0.0.1',port=9881,access_log=False)
