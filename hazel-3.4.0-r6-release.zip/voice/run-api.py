"""Launch official API without logging each spoken sentence to stdout."""
import os, runpy, sys, json
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path(json.loads((root/'runtime.local.json').read_text(encoding='utf-8'))['repo'])
os.chdir(repo)
sys.path.insert(0,str(repo))
sys.argv=[str(repo/'api_v2.py'),'-a','127.0.0.1','-p','9880','-c',str(root/'infer.yaml')]
sys.stdout=open(os.devnull,'w',encoding='utf-8')
runpy.run_path(str(repo/'api_v2.py'),run_name='__main__')
