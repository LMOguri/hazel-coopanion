import argparse,json,sys,hashlib,urllib.request
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--download-models',action='store_true')
a=p.parse_args(); root=Path(__file__).resolve().parent; repo=a.repo.resolve()
assert (repo/'api_v2.py').is_file(), 'Expected GPT-SoVITS repository'
models=json.loads((root/'models.json').read_text())
for m in models:
    dest=repo/'GPT_SoVITS/pretrained_models'/m['path']
    if not dest.exists() and a.download_models:
        dest.parent.mkdir(parents=True,exist_ok=True)
        temp=dest.with_suffix(dest.suffix+'.part')
        urllib.request.urlretrieve(m['url'],temp)
        assert hashlib.sha256(temp.read_bytes()).hexdigest()==m['sha256'], 'Download checksum mismatch'
        temp.replace(dest)
    assert dest.is_file(), 'Missing model: '+m['path']
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==m['sha256'], 'Model checksum mismatch: '+m['path']
assert (repo/'GPT_SoVITS/text/G2PWModel/g2pW.onnx').is_file(), 'Install G2PWModel first (see AGENTS.md)'
(root/'runtime.local.json').write_text(json.dumps({'repo':str(repo),'python':sys.executable},indent=2),encoding='utf-8')
print('Configured; run start-api.ps1 next')
