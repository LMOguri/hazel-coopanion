import { createSpeech as createOriginalSpeech } from './speech.js';
export { textSteps } from './speech.js';

// The existing pet CSP permits local WebSockets. No CSP relaxation is needed.
function requestAudio(text, signal) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket('ws://127.0.0.1:9881/speech');
    socket.binaryType = 'arraybuffer';
    let settled = false;
    const finish = (error, bytes) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener('abort', abort);
      socket.onopen = socket.onmessage = socket.onerror = socket.onclose = null;
      socket.close();
      error ? reject(error) : resolve(bytes);
    };
    const abort = () => finish(new DOMException('Cancelled', 'AbortError'));
    signal.addEventListener('abort', abort, { once: true });
    socket.onopen = () => socket.send(JSON.stringify({ text }));
    socket.onmessage = (event) => event.data instanceof ArrayBuffer
      ? finish(null, event.data) : finish(new Error('Invalid voice response'));
    socket.onerror = () => finish(new Error('Local voice connection failed'));
    socket.onclose = () => finish(new Error('Local voice connection closed'));
    if (signal.aborted) abort();
  });
}

/** Full-sentence speech for Hazel; shares the app's talk mute and master gain. */
export function createSpeech(sfx, { onUnit = () => {}, isHazel = () => false } = {}) {
  const original = createOriginalSpeech(sfx, { onUnit });
  let enabled = false, serial = 0, request = null, source = null, timer = null;
  let pending = false, mode = false, text = '';
  function clear() {
    serial++;
    request?.abort(); request = null;
    if (source) { source.onended = null; try { source.stop(); } catch {} source.disconnect(); source = null; }
    if (timer) clearInterval(timer);
    timer = null; pending = false; text = '';
  }
  function allowed() { return enabled && isHazel() && Boolean(sfx.output('talk')); }
  function finish(id) {
    if (id !== serial) return;
    if (timer) clearInterval(timer);
    timer = null; pending = false;
    source?.disconnect(); source = null; request = null;
  }
  return {
    configure(options = {}) {
      original.configure(options);
      if (typeof options.enabled === 'boolean') enabled = options.enabled;
      if (!enabled) { clear(); mode = false; }
    },
    get active() { return mode ? true : original.active; },
    get busy() {
      if (mode && pending && !allowed()) clear();
      return mode && pending;
    },
    begin(value) {
      clear(); original.stop(); mode = enabled && isHazel();
      if (!mode) { original.begin(value); return; }
      text = value;
      if (!allowed() || !value.trim()) return;
      const id = serial, aborter = new AbortController(); request = aborter; pending = true;
      const timeout = setTimeout(() => aborter.abort(), 45000);
      timer = setInterval(() => {
        if (!allowed()) { clear(); return; }
        if (source) onUnit();
      }, 180);
      requestAudio(value, aborter.signal).then(async (bytes) => {
        if (id !== serial || !allowed()) return;
        const output = sfx.output('talk');
        const buffer = await output.ctx.decodeAudioData(bytes);
        if (id !== serial || !allowed()) return;
        source = output.ctx.createBufferSource(); source.buffer = buffer;
        source.connect(output.master);
        source.onended = () => finish(id);
        source.start();
      }).catch((error) => {
        if (id === serial && error.name !== 'AbortError') console.warn('灰泽满语音暂不可用，保留文字回复。', error.message);
        finish(id);
      }).finally(() => clearTimeout(timeout));
    },
    reveal(index) { return mode ? true : original.reveal(index); },
    stop() { clear(); mode = false; original.stop(); },
  };
}
