$ErrorActionPreference = 'Stop'
$VoiceRoot = $PSScriptRoot
$RepoRoot = (Get-Content (Join-Path $PSScriptRoot 'runtime.local.json') -Raw | ConvertFrom-Json).repo
$LocalConfig = Get-Content (Join-Path $PSScriptRoot 'runtime.local.json') -Raw | ConvertFrom-Json
$Python = $LocalConfig.python
$StatePath = Join-Path $VoiceRoot 'services.local.json'
$State = @{}
if (Test-Path -LiteralPath $StatePath) {
  $Saved = Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
  foreach ($Property in $Saved.PSObject.Properties) { $State[$Property.Name] = $Property.Value }
}
function Test-OwnedProcess($Name) {
  if (-not $State.ContainsKey($Name)) { return $false }
  $Entry = $State[$Name]
  $Process = Get-Process -Id $Entry.pid -ErrorAction SilentlyContinue
  return $Process -and ($Process.Path -eq $Python) -and ($Process.StartTime.ToUniversalTime().Ticks.ToString() -eq $Entry.started)
}
$Listener = Get-NetTCPConnection -LocalPort 9880 -State Listen -ErrorAction SilentlyContinue
$env:PYTHONUTF8 = '1'
$env:CUDAGraph = '0'
$env:OMP_NUM_THREADS = '4'
$env:MKL_NUM_THREADS = '4'
if (-not $Listener -and -not (Test-OwnedProcess 'api')) {
  $Process = Start-Process -FilePath $Python -ArgumentList @("`"$VoiceRoot\run-api.py`"") -WorkingDirectory $RepoRoot -WindowStyle Hidden -RedirectStandardOutput "$VoiceRoot\api.log" -RedirectStandardError "$VoiceRoot\api-error.log" -PassThru
  $State['api'] = @{ pid = $Process.Id; started = $Process.StartTime.ToUniversalTime().Ticks.ToString() }
}
if (-not (Get-NetTCPConnection -LocalPort 9881 -State Listen -ErrorAction SilentlyContinue) -and -not (Test-OwnedProcess 'bridge')) {
  $Process = Start-Process -FilePath $Python -ArgumentList @("`"$VoiceRoot\bridge.py`"") -WorkingDirectory $VoiceRoot -WindowStyle Hidden -RedirectStandardOutput "$VoiceRoot\bridge.log" -RedirectStandardError "$VoiceRoot\bridge-error.log" -PassThru
  $State['bridge'] = @{ pid = $Process.Id; started = $Process.StartTime.ToUniversalTime().Ticks.ToString() }
}
$State | ConvertTo-Json | Set-Content -LiteralPath $StatePath -Encoding utf8
Write-Host 'Voice API starting on http://127.0.0.1:9880; see api.log and api-error.log.'
