$ErrorActionPreference = 'Stop'
$StatePath = Join-Path $PSScriptRoot 'services.local.json'
$LocalConfig = Get-Content (Join-Path $PSScriptRoot 'runtime.local.json') -Raw | ConvertFrom-Json
$Python = $LocalConfig.python
if (-not (Test-Path -LiteralPath $StatePath)) { exit 0 }
$State = Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
foreach ($Entry in $State.PSObject.Properties.Value) {
  $Process = Get-Process -Id $Entry.pid -ErrorAction SilentlyContinue
  if ($Process -and ($Process.Path -eq $Python) -and ($Process.StartTime.ToUniversalTime().Ticks.ToString() -eq $Entry.started)) {
    Stop-Process -Id $Process.Id
  }
}
Write-Host 'Stopped owned voice services.'
