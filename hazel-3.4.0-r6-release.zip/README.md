# 灰泽满

作者：栗帽 · 形象 3.4.0 · 发布修订 r6

包含形象、人设与语料、ChatGPT 订阅接入及本地语音适配（v5 Turbo、E 音色、1.2 倍速）。

将本目录交给 Agent，按 [AGENTS.md](AGENTS.md) 安装。仅使用形象时，在 Coopanion 装扮页导入 `hazel-3.4.0.zip`。
