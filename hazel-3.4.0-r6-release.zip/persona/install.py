from pathlib import Path

import argparse, ast, datetime, hashlib, json, shutil, urllib.request

def sha(data): return hashlib.sha256(data).hexdigest()

def api(base, path, body=None):
    payload = None if body is None else json.dumps(body, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(base.rstrip('/')+'/api/'+path, data=payload,
                                 headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=60) as response: return json.load(response)

def install(base,workspace,content,metadata):
    workspace=workspace.resolve(); assert (workspace/'CONSTITUTION.md').is_file()
    docs=api(base,'prompts')['prompts']; doc=next(p for p in docs if p['key']=='constitution')
    old=(workspace/'CONSTITUTION.md').read_text(encoding='utf-8')
    assert old==doc['content'], 'Workspace does not match the running application'
    backup=ROOT/'private-backups'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup.mkdir(parents=True)
    shutil.copy2(workspace/'CONSTITUTION.md',backup/'CONSTITUTION.md')
    result=api(base,'prompts',{'key':'constitution','content':content,'baseRevision':doc['revision']})
    assert result.get('ok'), result
    assert (workspace/'CONSTITUTION.md').read_text(encoding='utf-8')==content
    reloaded=api(base,'session/reload-prefix',{})
    assert reloaded.get('ok'), reloaded
    preview=api(base,'prompts/prefix')
    assert any(content.strip() in s.get('text','') for s in preview['segments'])
    after=api(base,'prompts')['prompts']
    assert all(next(p['revision'] for p in after if p['key']==d['key'])==d['revision'] for d in docs if d['key']!='constitution')
    report={**metadata,'installed':True,'reload':reloaded,'other_prompt_documents_unchanged':True,
            'backup':str(backup),'workspace':str(workspace)}
    (ROOT/'install-report.local.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'installed':True,'chars':len(content),'reload':reloaded,'backup':str(backup)},ensure_ascii=True))

ROOT = Path(__file__).resolve().parent

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--workspace',type=Path,required=True)
    parser.add_argument('--base-url',default='http://127.0.0.1:17788')
    args=parser.parse_args()
    content=(ROOT/'payload'/'CONSTITUTION.md').read_text(encoding='utf-8')
    metadata=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    assert sha(content.encode('utf-8'))==metadata['constitution_sha256'], 'Persona checksum mismatch'
    install(args.base_url,args.workspace,content,metadata)
