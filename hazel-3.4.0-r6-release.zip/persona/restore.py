from pathlib import Path
import argparse, datetime, json
from install import api

p=argparse.ArgumentParser()
p.add_argument('--backup',type=Path,required=True)
p.add_argument('--base-url',default='http://127.0.0.1:17788')
a=p.parse_args()
content=a.backup.read_text(encoding='utf-8')
doc=next(d for d in api(a.base_url,'prompts')['prompts'] if d['key']=='constitution')
before=Path(__file__).resolve().parent/'private-backups'/('before-restore-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
before.mkdir(parents=True)
(before/'CONSTITUTION.md').write_text(doc['content'],encoding='utf-8')
r=api(a.base_url,'prompts',{'key':'constitution','content':content,'baseRevision':doc['revision']})
assert r.get('ok')
print(json.dumps(api(a.base_url,'session/reload-prefix',{}),ensure_ascii=True))
